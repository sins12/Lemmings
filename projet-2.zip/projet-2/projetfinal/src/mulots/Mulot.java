package mulots;

import java.awt.Point;
import partie.IMulot;

/**
 * Classe Mulot qui impl�mente l'interface IMulot
 * Compos� de Direction(enum), direction, Point, chuteMortelle, chute
 */
public abstract class Mulot implements IMulot {
	enum DIRECTION {gauche, droite}
	private DIRECTION direction;
	private Point coord = new Point();
	private int chuteMortelle = 6;
	private int chute = 0;
		
	/**
	 * @param x : la position en x
	 * @param y : la position en y
	 * @param direction : la direction du mulot
	 */
	public Mulot(int x, int y, String direction){
		coord.x=x;
		coord.y=y;
		if(direction=="gauche"){
			this.direction=DIRECTION.gauche;
		}else{
			this.direction=DIRECTION.droite;
		}
	}
	public int getChuteMortelle(){ return chuteMortelle;}
	public int getChute(){ return chute;}
	public void initChute(){
		chute = 0;
	}
	/**
	 * @see partie.IMulot#changerDirection()
	 * Pour changer de Direction
	 */
	public void changerDirection(){
		if(direction == DIRECTION.droite){direction = DIRECTION.gauche;}
		else{direction = DIRECTION.droite;}
	}
	/**
	 * @see partie.IMulot#getDirection()
	 * Pour retourner la direction
	 * @return String
	 */
	public String getDirection(){
		if(direction == DIRECTION.droite){ return "droite";}
		else { return "gauche";}
	}
	public char getChar(){
		return 'm';
	}
	/**
	 * @see partie.IMulot#monter()
	 * Monter dans le tableau
	 */
	public void monter(){
		this.coord.y--;
		initChute();
	}
	/**
	 * @see partie.IMulot#descendre()
	 * Descendre dans le tableau
	 */
	public void descendre(){
		this.coord.y++;
		chute++;
	}
	public void setY(int y) {coord.y = y;}
	/**
	 * @see partie.IMulot#allerADroite()
	 * Aller � droite dans le tableau
	 */
	public void allerADroite(){
		this.coord.x++;
		initChute();
	}
	/**
	 * @see partie.IMulot#allerAGauche()
	 * Aller � droite dans le tableau
	 */
	public void allerAGauche(){
		this.coord.x--;
		initChute();
	}
	public int getY() {return coord.y;}
	public int getX() {return coord.x;}
}
