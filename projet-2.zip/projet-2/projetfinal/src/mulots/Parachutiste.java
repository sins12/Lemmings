package mulots;

/**
 * Classe Parachutiste h�ritant de la classe Mulot
 * Compos� de 4 m�thodes
 */
public class Parachutiste extends Mulot{

	public Parachutiste(int x, int y, String direction) {	
		super(x, y, direction);
	}
	
	@Override
	public char getChar(){
		return 'p';
	}
	
	@Override
	public String getType(){
		return "Parachutiste";
	}
	@Override
	public void descendre(){
		setY(getY()+1);
		initChute();
	}
}
