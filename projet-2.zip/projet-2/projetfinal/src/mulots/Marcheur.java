package mulots;

/**
 * Classe Marcheur heritant de la classe Mulot
 * Compos� de 2 m�thodes
 */
public class Marcheur extends Mulot {
	public Marcheur(int x, int y) {
		super(x, y, "droite");
	}	
	@Override
	public String getType(){
		return "Marcheur";
	}
}
