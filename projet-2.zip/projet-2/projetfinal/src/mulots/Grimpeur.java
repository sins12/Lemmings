package mulots;

/**
 * Classe Grimpeur h�ritant de la classe Mulot
 * Compos� de 3 m�thodes
 */
public class Grimpeur extends Mulot{
	public Grimpeur(int x, int y, String direction) {	
		super(x, y, direction);
	}
	@Override
	public String getType(){
		return "Grimpeur";
	}
	@Override
	public char getChar(){
		return 'g';
	}
}
