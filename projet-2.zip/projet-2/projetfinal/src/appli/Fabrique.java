package appli;

import mulots.*;
import partie.IFabrique;
import partie.IMulot;

/**
 * Cette classe impl�mente l'interface IFabrique
 * Compos� de la m�thode create
 */
public class Fabrique implements IFabrique {
	/**
	 * @see partie.IFabrique#create(java.lang.String, int, int, java.lang.String)
	 * M�thode avec un switch permettant de creer des Imulots
	 * soit marcheur, soit grimpeur, soit parachutiste 
	 * @param profession : la profession souhait�e
	 * @param x : la position en x
	 * @param y : la position en y
	 * @direction : la direction du mulot
	 * @return m : le Imulot cr��
	 */
	public IMulot create(String profession, int x, int y, String direction){
		IMulot m;
		switch(profession){
			case "Marcheur" :
				m = new Marcheur(x, y);
				break;
			case  "Grimpeur" :
				m = new Grimpeur(x, y, direction);
				break;
			case "Parachutiste" :
				m = new Parachutiste(x, y, direction);
				break;
			default : m = null;
		}
		return m;
	}
}
