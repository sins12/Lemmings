package appli;

import static outils.Outils.clavier;
import static outils.Outils.pause;
import java.util.Scanner;
import outils.Outils;
import partie.Niveau;
import partie.Partie;
/**
 * Application illustrant la lecture non bloquante de donnees au clavier.
 * Elle est compos� du main qui met en place un niveau de 40 colonnes et
 * 20 lignes avec l'entree
 * en 3,1 et la sortie en 38,17 avec 2 mulot initial et 1 mulot minimum a sauver,
 * 3 vie grimpeur, 3 vie Parachutiste
 * On cree differentes ploateforme et mur de largeur et longueur choisi
 * On lance une partie
 * On fait la boucle de jeu
 * On fait ensuite des scanners et on affiche les messages pour les vies
 * en fonction des valeurs des if
 * Plus VITESSE est grand, plus les mulots se deplacent rapidement
 * @param args
 */
public class AppliTexte {
	private static final double VITESSE = 3.;
	
	public static void main(String[] args)  {
		Fabrique fab = new Fabrique();
		Niveau niv1 = new Niveau(40, 20, 3, 1, 38, 17, 2, 1, 3, 3); 	
		
		niv1.plateforme(2, 18, 37); 									
		niv1.creerMur(4, 15, 3);										
		niv1.creerPlateforme(3, 6, 12);									
		niv1.creerPlateforme(14, 10, 8);								
		niv1.creerMur(9, 22, 2);						
		niv1.creerPlateforme(20, 8, 3);
		niv1.creerPlateforme(7, 12, 12);
		niv1.creerPlateforme(19, 15, 4);
		niv1.creerMur(10, 7, 2);
		niv1.creerPlateforme(23, 16, 12);
		
		Partie p = new Partie(niv1);
		p.lancer(fab);
		Outils.pause(1/VITESSE);

		boolean escape = false;
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		do {
			if (clavier()) {
				String s = sc.next();

				if (s.length() >= 1) {
					switch (s.charAt(0)) {
					case 'q':
					case 'Q':
						escape = true;
						break;
					case 'G':
					case 'g' :
						if(niv1.getNbVieG()>0){
							int i=0;
							while(p.getListeMulots().get(i).getType() == "Grimpeur"){
								i++;
							}
							p.changerProfession(p.getListeMulots().get(i), "Grimpeur", fab);
							niv1.utiliserVieG();
						}else
							System.out.println("Plus de vie Grimpeur !");
						break;
					case 'p' :
					case 'P' :
						if(niv1.getNbVieP()>0){
							int i=0;
							while(p.getListeMulots().get(i).getType() == "Parachutiste"){
								i++;
							}
							p.changerProfession(p.getListeMulots().get(i), "Parachutiste", fab);
							niv1.utiliserVieP();
						}else
							System.out.println("Plus de vie Parachutiste !");
						break;
					default:
						System.out.println("not yet implemented");
						pause(2);
					}
				}
			} else
				p.deplacerLesMulots(fab);
			System.out.println("tapez q (suivi de 'return') pour abandonner");
			System.out.println(niv1.NbVies());
			p.afficher();
			pause(1/VITESSE);
		} while (!escape && !p.fin());
	}
}
