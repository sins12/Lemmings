package outils;
import java.io.IOException;
import java.io.PushbackInputStream;

/**
 * Classe regroupant deux methodes statiques utilitaires.
 */
public class Outils {
	private static PushbackInputStream kbObserver = new PushbackInputStream(System.in);

	/**
	 * Indique si le buffer associe au clavier contient des donnees.
	 * @return Vrai si des donnees sont pretes e etre lue.
	 */
	public static boolean clavier() {
		try {
			return kbObserver.available() > 0;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return false;
	}
	/**
	 * Interrompt le programme pendant un laps de temps.
	 * @param secondes Duree (en secondes) de l'interruption.
	 */
	public static void pause(double secondes) {
		try {
			Thread.sleep((int) (1000 * secondes));
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
