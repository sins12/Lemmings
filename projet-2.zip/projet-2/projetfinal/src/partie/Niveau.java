package partie;

import java.awt.Point;

/**
 * Classe Niveau compos� d'un tableau � 2 dimensions,
 * du nombre de colonnes (nbc), du nombre de lignes (nbl)
 * des points d'entr�e et de sortie du niveau,
 * du nombre de mulots initiaux, minimum � sauver
 * et du nombre de vies des professions 
 */
public class Niveau {
		private int nbc, nbl;
		private Point entree, sortie;
		private char tab[][];
		private int nbMulotsInitials, nbMulotsMinimumASauver, nbVieGrimpeur, nbVieParachutiste;	
		/**
		 * @param x : position en x
		 * @param y : position en y
		 * @return : un caract�re
		 */
		public char get(int x, int y){
			return tab[x][y];
		}
		/**
		 * @return : le nombre de vies
		 */
		public String NbVies(){ 
			return nbVieGrimpeur + " vie(s) Grimpeur et " + nbVieParachutiste + " vie(s) Parachutiste" ;
		}
		/**
		 * @return : le nombre de vies de grimpeur
		 */
		public int getNbVieG(){ return nbVieGrimpeur; }
		/**
		 * @return : le nombre de vies de parachutiste
		 */
		public int getNbVieP(){ return nbVieParachutiste; }
		/**
		 * D�cr�mente le nombre de vies de grimpeur
		 */
		public void utiliserVieG(){
			nbVieGrimpeur--;
		}
		/**
		 * D�cr�mente le nombre de vies de parachutiste 
		 */
		public void utiliserVieP(){
			nbVieParachutiste--;
		}
		/**
		 * @return : le nombre de mulots initiaux
		 */
		public int getNbMulotsInitials(){ return nbMulotsInitials;}
		public int getColonnes(){return nbc;}
		public int getLignes(){return nbl;}
		/**
		 * Met en place le niveau de jeu sur le tableau de char
		 * @param nbc : nombre de colonnes
		 * @param nbl : nombre de lignes
		 * @param ex : coordonn�es entr�e en x
		 * @param ey : coordonn�es entr�e en y
		 * @param sx : coordonn�es sortie en x
		 * @param sy : coordonn�es sortie en y
		 * @param nbM : nombre de mulots initiaux
		 * @param nbMulotsASauver : nombre de mulots � sauver
		 * @param vG : nombres de vies de grimpeur
		 * @param vP : nombre de vies de parachutiste
		 */
		public Niveau(int nbc, int nbl, int ex, int ey, int sx, int sy, int nbM, int nbMulotsASauver, int vG, int vP) {
			this.nbc = nbc;
			this.nbl = nbl;
			tab = new char[nbc][nbl];
			for(int i = 0; i < nbc; i++){
				for(int j = 0; j < nbl; j++){
					tab[i][j] = ' ';
				}
			}
			entree = new Point(ex, ey);
			sortie = new Point(sx, sy);
			set(ex, ey, 'E');
			set(sx, sy, 'S');
			nbMulotsInitials = nbM;
			this.nbMulotsMinimumASauver = nbMulotsASauver;
			nbVieGrimpeur = vG;
			nbVieParachutiste = vP;
		}
		/**
		 * Set un caract�re en position dans le tableau
		 * @param x : position en x
		 * @param y : position en y
		 * @param c : caract�re du tableau
		 */
		public void set(int x, int y, char c){
			this.tab[x][y] = c;
		}
		public Point getEntree(){ return entree;}
		public Point getSortie(){ return sortie;}
		/**
		 * Permet de creer la plateforme de debut de niveau
		 * @param gx : position en x
		 * @param gy : position en y
		 * @param nb : longueur de la plateforme
		 */
		public void plateforme(int gx, int gy, int nb) {
			for (int col = gx; col < gx + nb; ++col)
				set(col, gy, '-');
		}
		/**
		 * Permet de creer un mur
		 * @param x : position en x
		 * @param y : position en y
		 * @param taille : longueur du mur
		 */
		public void creerMur(int x, int y, int taille){
			for(int i = x; i <= x + taille - 1; i++){
				for(int j = 0; j <= this.nbc; j++){
					if(j == y){
						set(j, i,'|');
					}
				}	
			}
		}
		/**
		 * Permet de creer les petites plateforme dans un niveau
		 * @param x : position en x
		 * @param y ; position en y
		 * @param taille : taille de la plateforme
		 */
		public void creerPlateforme(int x, int y, int taille){
			for(int i=x; i<= x + taille - 1; i++){
				for(int j = 0; j<= this.nbl; j++){
					if(j == y){
						set(i, j, '_');
					}
				}
			}
		}

		/**
		 * Renvoie la hauteur d'un mur
		 * @param p : le point dans le tableau
		 * @return : la hauteur
		 */
		public int hauteurMur(Point p){
			int hauteur=0; 
			if(estUnMur(p.x, p.y)==true){
				hauteur=1;
				while(estUnMur(p.x, p.y-1)){
					hauteur++;
				}
			}
			return hauteur;
		}
		/**
		 * Verifie si il y a un plafond au point donnee
		 * @param x : la position en x
		 * @param y : la position en y
		 * @return : true ou false en fonction de s'il y a un plafond ou non
		 */
		public boolean estUnPlafond (int x, int y){
			if (estUnMur(x,y)){return true;} else{return false;}
		}
		/**
		 * Verifie si il y a un mur ou plateforme ou plafond au point donnee
		 * @param x : position en x
		 * @param y : position en y
		 * @return : true ou false en fonction de s'il y a un mur ou non
		 */
		public boolean estUnMur (int x, int y){
			if (tab[x][y] == '|' || tab[x][y] == '-' || tab[x][y] == '*' || tab[x][y] == '_'){return true;} else{return false;}
		}
		/**
		 * Verifie si il n'y a pas de mur
		 * @param x : position en x
		 * @param y : position en y
		 * @return : true ou false en fonction de s'il n'y pas de mur
		 */
		public boolean estVide (int x, int y){
			if (!estUnMur(x,y)){return true;} else{return false;}
		}
		/**
		 * @return : le nombre de mulots � sauver au minimum
		 */
		public int getNbMulotsMinimumASauver() {
			return nbMulotsMinimumASauver;
		}
}
