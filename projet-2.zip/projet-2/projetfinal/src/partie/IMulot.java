package partie;

/**
 * Interface IMulot compos� des m�thodes de Mulot
 */
public interface IMulot {

	void changerDirection();
	String getDirection();
	char getChar();
	void monter();
	void descendre();
	void allerADroite();
	void allerAGauche();
	int getY();
	int getX();
	String getType();
	int getChuteMortelle();
	int getChute();
	void initChute();
}

