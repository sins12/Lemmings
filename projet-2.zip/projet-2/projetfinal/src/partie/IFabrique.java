package partie;

/**
 * Interface IFabrique compos� de la m�thode create de la classe Fabrique
 */
public interface IFabrique {
	IMulot create(String profession, int x, int y, String direction);
}
