package partie;

import java.util.ArrayList;

/**
 * Classe Partie qui lance la partie
 * Compos� de niveau, l'ArrayList mulots, le nombre de mulots sortis
 * et les m�thodes associ�s
 */
public class Partie {
	Niveau niveau;
	private ArrayList<IMulot> mulots = new ArrayList<IMulot>();
	int NbMulotsVainqueur;
	
	/**
	 * Constructeur Partie
	 * @param n : le niveau
	 */
	public Partie (Niveau n){
		niveau = n;
		NbMulotsVainqueur = 0;
	}
	/**
	 * @return mulots: la liste de mulots
	 */
	public ArrayList<IMulot> getListeMulots(){
		return this.mulots;
	}
	/**
	 * Affiche le niveau, caract�res du tableau � deux dimensions, 
	 * En fonction de nbc et nbl
	 */
	public void afficher() {
		for (int lig = 0; lig < niveau.getLignes(); ++lig) {
			for (int col = 0; col < niveau.getColonnes(); ++col){
				for( IMulot m : mulots){
					if(m.getX()==lig && m.getY()==col){
						niveau.set(lig, col, m.getChar());
					}
				}
				System.out.print(niveau.get(col, lig));
			}
			System.out.println();
		}
	}
	/**
	 * Lib�re une case, remplace par le caract�re vide
	 * @param x : position en x
	 * @param y : position en y
	 */
	public void libererCase(int x, int y){
		niveau.set(x, y, ' ');
	}
	/**
	 * Fait na�tre un mulot au d�but du niveau
	 * @param fab : IFabrique
	 */
	public void naissance(IFabrique fab) {
		if (!niveau.estUnMur(niveau.getEntree().x, (niveau.getEntree().y + 1))){
			mulots.add(fab.create("Marcheur",niveau.getEntree().x, niveau.getEntree().y +1, "droite"));
		}
	}
	/**
	 * Fait monter le caract�re du mulot d'une case dans le niveau
	 * @param m : Imulot
	 */
	public void monter(IMulot m){
		niveau.set(m.getX(), m.getY(), ' ');
		if(!tuer(m)){
			m.monter();
			niveau.set(m.getX(), m.getY(), m.getChar());
		}
	}
	/**
	 * Fait descendre le caract�re du mulot d'une case dans le niveau
	 * @param m : Imulot
	 */
	public void descendre(IMulot m){
		niveau.set(m.getX(), m.getY(), ' ');
		if(!tuer(m)){
			m.descendre();
			niveau.set(m.getX(), m.getY(), m.getChar());
		}
	}
	/**
	 * Fait aller � droite le mulot
	 * En r�alit� il meurt et rena�t � cot�
	 * @param m : Imulot
	 */
	public void allerADroite(IMulot m){
		niveau.set(m.getX(), m.getY(), ' ');
		if(!tuer(m)){
			m.allerADroite();
			niveau.set(m.getX(), m.getY(), m.getChar());
		}
	}
	/**
	 * Fait aller � gauche le mulot
	 * En r�alit� il meurt et rena�t � cot�
	 * @param m : Imulot
	 */
	public void allerAGauche(IMulot m){
		niveau.set(m.getX(), m.getY(), ' ');
		if(!tuer(m)){
			m.allerAGauche();
			niveau.set(m.getX(), m.getY(), m.getChar());
		}
	}
	/**
	 * Permet de d�placer un mulot grimpeur
	 * Il grimpe si il rencontre un mur et redevient marcheur ensuite
	 * @param m : Imulot
	 * @param fab : IFabrique
	 */
	public void deplacementGrimpeur(IMulot m, IFabrique fab){
		//si il va a gauche
	  	if(m.getDirection()=="gauche"){
	  		//si a gauche ya un mur
	  		if(niveau.estUnMur(m.getX()-1, m.getY())){
	  			//si ya pas de plafond juste au dessus de lui
	  			if(!niveau.estUnPlafond(m.getX(), m.getY()-1)){
	  				//il monte
	  				monter(m);
	  			//sinon il descend
	  			}else{
	  				//si ya pas de mur en dessous de lui
	  				if(!niveau.estUnMur(m.getX(), m.getY()+1)){
	  					descendre(m);
	  					changerEnMulotMarcheur(m, fab);
	  				//sinon il change de direction
	  				}else{
	  					m.changerDirection();
	  				}
	  			}
	  		//si a gauche ya pas de mur
	  		}else{
	  			//si c'est pas vide en dessous de lui
	  			if(!niveau.estVide(m.getX(), m.getY()+1)){
	  				//il va a gauche
	  				allerAGauche(m);
	  			}else{
	  				//si ya un mur en bas a gauche
	  				if(niveau.estUnMur(m.getX()-1, m.getY()+1)){
	  					allerAGauche(m);
	  				}else{
	  					//sinon il descend
		  				descendre(m);
		  				changerEnMulotMarcheur(m, fab);
	  				}
	  			}
	  		}
	  	}else{
	  		///si a droite ya un mur
	  		if(niveau.estUnMur(m.getX()+1, m.getY())){
	  			//si ya pas de plafond juste au dessus de lui
	  			if(!niveau.estUnPlafond(m.getX(), m.getY()-1)){
	  				//il monte
	  				monter(m);
	  			//sinon il descend
	  			}else{
	  				//si ya pas de mur en dessous de lui
	  				if(!niveau.estUnMur(m.getX(), m.getY()+1)){
	  					descendre(m);
	  					changerEnMulotMarcheur(m, fab);
	  				//sinon il change de direction
	  				}else{
	  					m.changerDirection();
	  				}
	  			}
	  		//si a droite ya pas de mur
	  		}else{
	  			//si c'est pas vide en dessous de lui
	  			if(!niveau.estVide(m.getX(), m.getY()+1)){
	  				//il va a droite
	  				allerADroite(m);
	  			}else{
	  				//si ya un mur en bas a droite
	  				if(niveau.estUnMur(m.getX()+1, m.getY()+1)){
	  					allerADroite(m);
	  				}else{
	  					//sinon il descend
		  				descendre(m);
		  				changerEnMulotMarcheur(m, fab);
	  				}
	  			}
	  		}
	  	}
	  	if (sortie(m)){
	  		NbMulotsVainqueur++;
	  		mulots.remove(m);
	  		niveau.set(m.getX(), m.getY(), 'S');
	  	}
	}
	/**
	 * Permet de d�placer un mulot marcheur et parachutiste
	 * Si c'est un marcheur il avance de gauche � droite
	 * et si il rencontre un mur il fait demi-tour
	 * Si c'est un parachutiste, il avance comme un mulot marcheur
	 * mais il n'a pas de chut mortelle
	 * et il redevient marcheur ensuite
	 * @param m : Imulot
	 * @param fab : IFabrique
	 */
	public void deplacerUnMulot(IMulot m, IFabrique fab) {
		if(!tuer(m)){
			switch (m.getType()){
			  case "Grimpeur":
				  deplacementGrimpeur(m, fab);
				  break;
			  case "Marcheur":
				  // Si c'est pas vide en dessous de lui:
				    if(!niveau.estVide(m.getX(), m.getY()+1)){
				    	//Si il se deplace vers la gauche
					  	if(m.getDirection()=="gauche"){
					  		//Si ya pas de mur a cote
					    	if(!niveau.estUnMur(m.getX()-1, m.getY())){
					    		// il bouge a cote
					    		allerAGauche(m);
					    	//sinon il change de direction
					    	}else{
					    		m.changerDirection();
					    	}
					    //sinon si il se deplace vers la droite
					    }else{
					    	//Si ya pas de mur a cote
					    	if(!niveau.estUnMur(m.getX()+1, m.getY())){
					    		// il bouge a cote
					    		allerADroite(m);
					    	//sinon il change de direction
					    	}else{
					    		m.changerDirection();
					    	}
					    }
					//sinon si c'est vide, il tombe.
				    }else{
				    	descendre(m);
				    }
				    if (sortie(m)){
				  		NbMulotsVainqueur++;
				  		mulots.remove(m);
				  	}
				    break; 
			  case "Parachutiste":
				  // Si c'est pas vide en dessous de lui:
				    if(!niveau.estVide(m.getX(), m.getY()+1)){
				    	//Si il se deplace vers la gauche
					  	if(m.getDirection()=="gauche"){
					  		//Si ya pas de mur a cote
					    	if(!niveau.estUnMur(m.getX()-1, m.getY())){
					    		// il bouge a cote
					    		allerAGauche(m);
					    	//sinon il change de direction
					    	}else{
					    		m.changerDirection();
					    	}
					    //sinon si il se deplace vers la droite
					    }else{
					    	//Si ya pas de mur a cote
					    	if(!niveau.estUnMur(m.getX()+1, m.getY())){
					    		// il bouge a cote
					    		allerADroite(m);
					    	//sinon il change de direction
					    	}else{
					    		m.changerDirection();
					    	}
					    }
					//sinon si c'est vide, il tombe.
				    }else{
				    	descendre(m);
				    	if(niveau.estUnMur(m.getX(), m.getY()+1))
				    		changerEnMulotMarcheur(m, fab);
				    }
				    if (sortie(m)){
				  		NbMulotsVainqueur++;
				  		mulots.remove(m);
				  	}
				    break; 
			  default:
			    /*Action*/;             
			}
			
		}
	}
	/**
	 * Changer le mulot en mulot marcheur
	 * @param m : Imulot
	 * @param fab : IFabrique
	 */
	public void changerEnMulotMarcheur(IMulot m, IFabrique fab){
		changerProfession(m, "Marcheur", fab);
	}
	/**
	 * Changer la profession du mulot
	 * @param m : Imulot 
	 * @param profession : la profession souhait�e
	 * @param fab : IFabrique
	 */
	public void changerProfession(IMulot m, String profession, IFabrique fab){
		for(int i=0; i<mulots.size(); i++){
			if(mulots.get(i)==m){
				switch(profession){
				case "Marcheur":
					mulots.set(i, fab.create("Marcheur",m.getX(), m.getY(), m.getDirection()));
					break;
				case "Grimpeur":
					mulots.set(i, fab.create("Grimpeur",m.getX(), m.getY(), m.getDirection()));
					break;
				case "Parachutiste" :
					mulots.set(i, fab.create("Parachutiste",m.getX(), m.getY(), m.getDirection()));
					break;
				}
			}
		}
	}
	/**
	 * D�place les mulots de la liste mulots
	 * @param fab : IFabrique
	 */
	public void deplacerLesMulots(IFabrique fab) {
		for(int i=0; i<mulots.size(); i++){
			deplacerUnMulot(mulots.get(i), fab);
		}
	}
	/**
	 * Lance la partie
	 * @param fab : IFabrique
	 */
	public void lancer(IFabrique fab){
		//naissance des mulots
		for (int i=0; i< niveau.getNbMulotsInitials(); i++){
			naissance(fab);
			deplacerLesMulots(fab);
			afficher();
		}
	}
	/**
	 * @param m : Imulot
	 * @return true ou false si le mulot est sur la sortie
	 */
	public boolean sortie(IMulot m){
		if(m.getX()==niveau.getSortie().x && m.getY()==niveau.getSortie().y){
			return true;
		}else{
			return false;
		}
	}
	/**
	 * Tue un mulot si il est hors de la plateforme, si il fait une chute mortelle
	 * ou s'il est sur la sortie du niveau
	 * @param m : Imulot
	 * @return true ou false en fonction de sa position
	 */
	public boolean tuer(IMulot m){
		boolean tuer=false;
		// il est plus sur le terrain
		if(m.getY()< 0 || m.getX()<0 || m.getY()>=niveau.getLignes()-1 || m.getX()>=niveau.getColonnes()-1){
			mulots.remove(m);
			tuer=true;
			niveau.set(m.getX(), m.getY(), ' ');
		}
		if(m.getChute() >= m.getChuteMortelle()){
			mulots.remove(m);
			tuer = true;
			niveau.set(m.getX(), m.getY(), ' ');
		}// il est sur la sortie
		if (sortie(m)){
			this.NbMulotsVainqueur++;
			int x = m.getX();
			int y = m.getY();
			mulots.remove(m);
			tuer= true;
			niveau.set(x, y, 'S');
		}
		return tuer;
	}
	/**
	 * Verifie si la partie est termin�e
	 * Affiche un message si on a gagn� ou perdu
	 * @return : true ou false en fonction de l'�tat de la partie
	 */
	public boolean fin(){
		boolean fin = false;
		if(mulots.size() == 0){
			fin = true;
		}
		if(niveau.getNbVieG() == 0 && niveau.getNbVieP() == 0){
			fin = true;
		}
		
		if(niveau.getNbMulotsMinimumASauver() <= NbMulotsVainqueur){
			System.out.println("Vous avez gagn� !");
		}else
			System.out.println("Vous avez Perdu !");
		System.out.println(NbMulotsVainqueur + " Mulot(s) sont Sorti(s)");
		
		return fin;
	}
}
